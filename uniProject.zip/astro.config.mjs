import { defineConfig } from "astro/config";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  vite: {
    plugins: [tailwindcss()],
  },
  output: "static",
  base: "/UniProject/",
  site: 'https://MerajMehdizade.github.io',
});
