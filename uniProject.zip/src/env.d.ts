/// <reference path="../.astro/types.d.ts" />
/// <reference types="astro/client" />

declare module '*.jpg';
declare module '*.jpeg';
declare module '*.png';
declare module '*.svg';
